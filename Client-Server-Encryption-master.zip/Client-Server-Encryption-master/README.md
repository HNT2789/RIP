Client-Server-Encryption
========================

How to run:
- Import the project to Eclipse
- Run the Server main
- Run the Client main
- They should connect automatically
- Now type text to be sent over

Use the Display Selected Console button in Eclipse to switch between the two.

Or compile & run in CLI in order to have separate windows to work with.
